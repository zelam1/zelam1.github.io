let colorChoice, red, orange, yellow, green, cyan, blue, magenta, brown, white, black;

function setup() {
  createCanvas(600, 300);
  background(245);
  colorChoice = 0;
  red = new colorBank(0, "red");
  orange = new colorBank(20, "orange");
  yellow = new colorBank(40, "yellow");
  green = new colorBank(60, "green");
  cyan = new colorBank(80, "cyan");
  blue = new colorBank(100, "blue");
  magenta = new colorBank(120, "magenta");
  brown = new colorBank(140, "brown");
  white = new colorBank(160, "white");
  black = new colorBank(180, "black");
}

function draw() 
{
  if(mouseIsPressed)
  {
    if(mouseX > 21)
    {
      drawing();
    }
  }

  red.appearance();
  red.onMousePressed(); 
  orange.appearance();
  yellow.appearance();
  green.appearance();
  cyan.appearance();
  blue.appearance();
  magenta.appearance();
  brown.appearance();
  white.appearance();
  black.appearance();
} 

class colorBank
{
  constructor(y, color)
  {
    this.x = 0;
    this.y = y;
    this.width = 20;
    this.height = 20;
    this.color = color;
  }
  appearance()
  {
    push();
    stroke(255);
    fill(this.color);
    rect(this.x, this.y, this.width, this.height);
    pop();
  }
  onMousePressed()
  {
    if(mouseIsPressed)
    {
    if(mouseX < 20)
    {
      if(mouseY > 0 && mouseY < 20)
      {
        colorChoice = "red";
      }
      else if(mouseY > 20 && mouseY < 40)
      {
        colorChoice = "orange";
      }
      else if(mouseY > 40 && mouseY < 60)
      {
        colorChoice = "yellow";
      }
      else if(mouseY > 60 && mouseY < 80)
      {
        colorChoice = "green";
      }
      else if(mouseY > 80 && mouseY < 100)
      {
        colorChoice = "cyan";
      }
      else if(mouseY > 100 && mouseY < 120)
      {
        colorChoice = "blue";
      }
      else if(mouseY > 120 && mouseY < 140)
      {
        colorChoice = "magenta";
      }
      else if(mouseY > 140 && mouseY < 160)
      {
        colorChoice = "brown";
      }
      else if(mouseY > 160 && mouseY < 180)
      {
        colorChoice = "white";
      }
      else if (mouseY > 180 && mouseY < 200)
      {
        colorChoice = "black";
      }
    }
    }
  }
}

function drawing()
{
  push();
  stroke(colorChoice);
  strokeWeight(5);
  line(pmouseX, pmouseY, mouseX, mouseY);
  pop();
}