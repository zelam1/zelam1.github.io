function setup() {
  createCanvas(350, 200);
  angleMode(DEGREES);
}
//Image 3: Pacman & Ghost.//
function draw() {
  background(0, 0, 0);
//Pacman//
  
  fill(255, 255, 0);
    circle(70, 100, 130);
  fill(0, 0, 0);
    arc(60, 100, 130, 130, 135, 225);
  
//Ghost//
  fill(255, 0, 0);
  arc(250, 100, 130, 130, 180, 360);
  fill(255, 0, 0);
  noStroke();
  rect(185, 100, 130, 70);
  ellipseMode(RADIUS);
    fill(255);
  ellipse(220, 100, 20, 20); 
  ellipseMode(CENTER);
  fill(0, 0, 255);
  ellipse(220, 100, 25, 25); 
  
  ellipseMode(RADIUS);
    fill(255);
  ellipse(283, 100, 20, 20); 
  ellipseMode(CENTER);
  fill(0, 0, 255);
  ellipse(283, 100, 25, 25); 
}