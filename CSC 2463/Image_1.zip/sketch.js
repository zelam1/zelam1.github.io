function setup() {
  createCanvas(750, 350);
}
//Image 1: Green background with white //
//square and circle. //
function draw() {
  background(0, 255, 0);
  fill(255);
  circle(200, 175, 300);
  square(400, 25, 300);
}