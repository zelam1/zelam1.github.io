function setup() {
  createCanvas(200, 200);
}

function draw() {
  background(255);
  noStroke();
  smooth();
  fill(255, 179, 191, 191);
  circle(100,60,100);
  
  noStroke();
  smooth();
  fill(77, 255, 106, 127);
  circle(140,120,100);
  
  noStroke();
  smooth();
  fill(43, 0, 255, 63);
  circle(70,120,100);
}