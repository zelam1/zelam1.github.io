let bkImage;
let pitch = 800;

let osc = new Tone.AMOscillator(pitch, 'sine', 'sine');
let gain = new Tone.Gain().toDestination();
let pan = new Tone.Panner().connect(gain);
let ampEnv = new Tone.AmplitudeEnvelope({
  attack: 0.1,
  decay: 0.2,
  sustain: 1.0,
  release: 1.0
}).connect(pan);
osc.connect(ampEnv);

let freqLFO = new Tone.LFO(4, 300, 1000).start();
freqLFO.connect(osc.frequency);


let noise1 = new Tone.Noise('white').start();
let noiseEnv1 = new Tone.AmplitudeEnvelope({
  attack: 0.1,
  decay: 0.2,
  sustain: 0.5,
  release: 1.0
}).connect(gain);
let noiseFilter1 = new Tone.Filter(800, 'lowpass').connect(noiseEnv1);
noise1.connect(noiseFilter1);

let noise2 = new Tone.Noise('pink').start();
let noiseEnv2 = new Tone.AmplitudeEnvelope({
  attack: 0.4,
  decay: 0.2,
  sustain: 1.0,
  release: 0.5
}).connect(gain);
let noiseFilter2 = new Tone.Filter(600, 'lowpass').connect(noiseEnv2);
noise2.connect(noiseFilter2);

let noise3 = new Tone.Noise('brown').start();
let noiseEnv3 = new Tone.AmplitudeEnvelope({
  attack: 0.5,
  decay: 0.5,
  sustain: 0.01,
  release: 0.01
}).connect(gain);

function preload(){
  bkImage = loadImage('css/Media/cloud.gif');
}

function setup() {
  createCanvas(400, 400);
}

function draw() {
if (mouseIsPressed) {
  background(bkImage);
} else {
  background(121, 160, 189);
  textSize(32);
  textFont("Calibri");
  textAlign(CENTER);
  fill(255, 255, 255);
  text('Click the canvas\n to see a storm!', 180, 170);

}
}
 
function mousePressed(){
  Tone.start();
  ampEnv.triggerAttackRelease('4n');
  osc.frequency.linearRampToValueAtTime(pitch - 200, '+1');
  ampEnv.triggerAttackRelease('4n', '+1');

  if(mouseY < 400 && mouseX < 400){
    background(255, 0, 245);
    noiseFilter1.frequency.value = mouseX + 600;
    noiseEnv1.triggerAttackRelease(0.3);
    noiseFilter2.frequency.value = mouseX + 300;
    noiseEnv2.triggerAttackRelease(1.0);
    noiseEnv3.triggerAttackRelease("4n", 0.5);
  }
}