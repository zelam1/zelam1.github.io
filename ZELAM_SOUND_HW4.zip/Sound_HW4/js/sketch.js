//Zoe Elam CSC Sound Final Project
//Music Credits & Inspiration: https://youtu.be/jXG-0LUApV8

let spriteSheet;
let spriteSheet2;
let spriteSheet3;
let spriteSheet4;
let spriteSheet5;
let character = [];
let count = 50;
let score, time, startTime;
let gameState = "wait";

const synth = new Tone.MembraneSynth().toDestination();
const synth2 = make_Instrument().instrument;
const synth3 = new Tone.AMSynth().toMaster();

let melody2 = new Tone.Sequence((time, note) =>{
  if(note != null){
    synth2.triggerAttackRelease(note, "2n", time);
  }
}, ["G#6", "C#6", null, "F#6", "G#6", "C#6"]);

var pianoPart = new Tone.Part(function(time, note) {
    synth3.triggerAttackRelease("C#4", "16n", time).loop = true;  
    synth2.triggerAttackRelease(note, "2n", time);
  }, [
    ["0:0", "G#5"],
    ["0:0.8", "F#5"],
    ["0:1.5", "E5"],
    ["0:2.2", "D#5"],
    ["0:2.8", "E5"],
    ["0:3.5", "B4"],
    ["0:4.5", "C#5"],
    ["0:5.5", "G#4"]
  ]).start();

  pianoPart.loop = true;

function timer(){
  return int((millis() - startTime) / 1000);
}

function preload(){
  spriteSheet = loadImage("css/Media/AmongPink.png");
  spriteSheet2 = loadImage("css/Media/AmongYellow.png");
  spriteSheet3 = loadImage("css/Media/AmongMint.png");
  spriteSheet4 = loadImage("css/Media/AmongCoral.png");
  spriteSheet5 = loadImage("css/Media/AmongGreen.png");
}


function setup(){
  createCanvas(600,600);
  imageMode(CENTER);
  Tone.start();
  melody2.start("0:0");
  pianoPart.start('0:0');
  Tone.Transport.start();

for(i = 0; i < count; i++){
   character[i] = new Character(random([spriteSheet, spriteSheet2, spriteSheet3, spriteSheet4, spriteSheet5]), 
   random(100, 500), random(100, 500), random(1, 5), random([-1, 1]), score);
    }
}

function mousePressed(){
  push();
  for(i = 0; i < count; i++){
    character[i].clicked();
  }
  pop();
}

function scoreControls(){
  push();
  score = 0;
  for(i = 0; i < count; i++){
    if(character[i].move == 0){
      score += 1;
    }
  }  
  pop();
  return score;
}

function draw(){
  background(0);

  if(gameState == 'wait'){
    fill(255);
    textSize(30);
    textFont("Trebuchet MS");
    text("Press the spacebar to start", 150, 300);
    if(keyCode === 32){
      startTime = millis();
      gameState = 'playing';
    }
  }else if(gameState == 'playing'){
    num_caught = 0;
    for(i = 0; i < count; i++){
      if(character[i].caught == true){
        num_caught ++;
      }
    }
    for(i = 0; i < count; i++){
      character[i].draw(num_caught);
    }
    score = scoreControls();
    time = timer();
    let totalTime = 30;
    fill(255);
    textSize(30);
    textFont("Trebuchet MS");
    text("TIME: " + (totalTime - time), 10, 30);
    text("SCORE: " + score, 10, 60);
    if(score >= 15){
      Tone.Transport.bpm.value += 2;
    }
    if (time >= totalTime || score == count){
      gameState = 'end';
  }
  }else if(gameState == 'end'){
    fill(255);
    textSize(30);
    textFont("Trebuchet MS");
    text("Game Over", 150, 200);
    text("Press the spacebar to restart", 150, 300);
    melody2.stop();
    pianoPart.stop();
    Tone.Transport.stop();
    if (keyIsPressed){
      if(keyCode === 32){
        setup();
        startTime = millis();
        gameState = 'playing';
      }
    }
  }
}
class Character{
  constructor(spriteSheet, x, y, speed, move){
    this.spriteSheet = spriteSheet;
    this.sx = 0;
    this.x = x;
    this.y = y;
    this.move = 0;
    this.facing = 1;
    this.speed = speed;
    this.move = move;
    this.facing = move;
  }

  draw(num_caught){
    push();
    translate(this.x, this.y);
    scale(this.facing, 1);

    if(this.move == 0){
      image(this.spriteSheet, 0, 0, 80, 80, 800, 0, 80, 80);
    }else{
      image(this.spriteSheet, 0, 0, 80, 80, 80 * (this.sx + 1), 0, 80, 80);
    }

    if(frameCount % 5 == 0){
      this.sx = (this.sx + 1) % 8;
    }
    this.x += (this.speed + num_caught) * this.move;

    if(this.x < 30){
      this.move = 1;
      this.facing = 1;
    }else if(this.x > width - 30){
      this.move = -1;
      this.facing = -1;
    }
    pop();
  }

  go(direction){
    this.move = direction;
    this.facing = direction;
    this.sx = 3;
  }

  stop(){
    this.move = 0;
  }

  clicked(){
    if(mouseX > this.x - 40 && mouseX < this.x + 40 &&
      mouseY > this.y - 40 && mouseY < this.y + 40){
      this.stop();
      this.caught = true;
      synth.triggerAttackRelease("A4", '4n');
      synth.triggerAttackRelease("D4", '4n');
      synth.triggerAttackRelease("G4", '4n');    }
  }
}


function make_Instrument() {
  // create synth
  var instrument = new Tone.AMSynth();
  var synthJSON = {
      "harmonicity": 2,
      "oscillator": {
          "type": "amsine2",
          "modulationType" : "sine",
          "harmonicity": 1.01
      },
      "envelope": {
          "attack": 0.006,
          "decay": 4,
          "sustain": 0.04,
          "release": 1.2
      },
      "modulation" : {
          "volume" : 13,
          "type": "amsine2",
          "modulationType" : "sine",
          "harmonicity": 12
      },
      "modulationEnvelope" : {
          "attack": 0.006,
          "decay": 0.2,
          "sustain": 0.2,
          "release": 0.4
      }
  };
  
  instrument.set(synthJSON);
  
  var effect1, effect2, effect3;
  
  // create effects
  var effect1 = new Tone.Phaser();
  effect1JSON = {
    "frequency": 4,
    "octaves": 0.4,
    "Q": 20,
    "baseFrequency": 800,
      "wet": 0.5
  };
  effect1.set(effect1JSON);
  
  
  // make connections
  instrument.connect(effect1);
  effect1.connect(Tone.Master);
  
  // define deep dispose function
  function deep_dispose() {
      if(effect1 != undefined && effect1 != null) {
          effect1.dispose();
          effect1 = null;
      }
      if(effect2 != undefined && effect2 != null) {
          effect2.dispose();
          effect2 = null;
      }
      if(effect3 != undefined && effect3 != null) {
          effect3.dispose();
          effect3 = null;
      }
      if(instrument != undefined && instrument != null) {
          instrument.dispose();
          instrument = null;
      }
  }
  
  
  return {
      instrument: instrument,
      deep_dispose: deep_dispose
      };
  
  }