let bkground;
let sounds = new Tone.Players({
  'duck': "css/media/duck.mp3",
  'eagle': 'css/media/eagle.mp3',
  'pigeon': "css/media/pigeon.mp3",
  'woodpecker': "css/media/woodpecker.mp3"
})
let soundsInOrder = ['duck', 'eagle', 'pigeon', 'woodpecker'];
let nextSoundPlayed = 0;

const delay = new Tone.FeedbackDelay("8n", 0.5);

let button1;
let button2;
let button3;
let button4;

let slider1;

function preload() {
 bkground = loadImage("css/media/BlueBird.jpg");
}

function setup() {
  createCanvas(400, 400);
  sounds.connect(delay);
  delay.toDestination();

  button1 = createButton("Duck", 'duck');
  button1.position(50, 70);
  button1.mousePressed( () => buttonSound('duck') );
  
  button2 = createButton("Pigeon", 'pigeon');
  button2.position(250, 70);
  button2.mousePressed( () => buttonSound('pigeon') );

  button3 = createButton("Eagle", 'eagle');
  button3.position(50, 300);
  button3.mousePressed( () => buttonSound('eagle') );

  button4 = createButton("Woodpecker", 'woodpecker');
  button4.position(250, 300);
  button4.mousePressed( () => buttonSound('woodpecker') );

  slider1 = createSlider(0., 1., 0.5, 0.05);
  slider1.mouseReleased(() => {
    delay.delayTime.value = slider1.value();
  })
}

function playSound(){
  sounds.player(soundsInOrder).start();
}

function draw() {
  background(bkground);
  fill(255);
  rect(65, 137, 245, 80);
  fill(0);
  textAlign(CENTER);
  textSize(35);
  textFont("Trebuchet MS");
  text("Click a bird to \nhear the call.", 0, 140, width);
  textAlign(LEFT);
  textSize(10);
  fill(255);
  rect(0, 370, 160, 10);
  fill(0);
  text("**Use the slider to effect the call.**", 0, 370, width);
}

function buttonSound(sound){
  sounds.player(sound).start();
}
