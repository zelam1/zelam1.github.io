//VIDEO LINK: https://drive.google.com/file/d/1COEWHNZh5PYYgWwWThh3Q6rFzFdm9TTh/view?usp=sharing

const synth = new Tone.Synth().toDestination();
let slider1, slider2;
const delay = new Tone.FeedbackDelay("1n", 0.5);
let bkImage;

function preload(){
bkImage = loadImage("80_rock.jpg");

}

const cheby = new Tone.Chebyshev(50).toDestination();
// create a monosynth connected to our cheby

let notes = {
  'a': 'C4',
  's': 'D4',
  'd': 'E4',
  'f': 'F4',
  'g': 'G4',
  'h': 'A4',
  'j': 'B4',
  'k': 'C5'
}

function setup() {
  createCanvas(400, 400);
  synth.connect(delay);
  delay.toDestination();
  synth.connect(cheby);
  cheby.toDestination();

  slider1 = createSlider(0., 1., 0.5, 0.05);
  slider1.mouseReleased(() => {
   delay.delayTime.value = slider1.value();
  })

  slider2 = createSlider(0., 1., 0.5, 0.05);
  slider2.mouseReleased(() => {
    cheby.value = slider2.value();  
  })
}

function draw() {
  background(bkImage);
  rect(0, 95, 400, 160);
  textAlign(CENTER);
  textFont("Arial");
  textSize(45);
  text("Use the slider to create a symphony of sounds!", 0, 100, width);
}

function keyPressed() {
  let toPlay = notes[key];
  console.log(toPlay);
  synth.triggerAttackRelease(toPlay, "8n");
}