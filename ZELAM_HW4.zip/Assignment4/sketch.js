let spriteSheet;
let spriteSheet2;
let spriteSheet3;
let spriteSheet4;
let spriteSheet5;
let character = [];
let count = 50;
let score, time, startTime;
let gameState = "wait";

function timer(){
  return int((millis() - startTime) / 1000);
}

function preload(){
  spriteSheet = loadImage("AmongPink.png");
  spriteSheet2 = loadImage("AmongYellow.png");
  spriteSheet3 = loadImage("AmongMint.png");
  spriteSheet4 = loadImage("AmongCoral.png");
  spriteSheet5 = loadImage("AmongGreen.png");
}

function setup(){
  createCanvas(600,600);
  imageMode(CENTER);

for(i = 0; i < count; i++){
   character[i] = new Character(random([spriteSheet, spriteSheet2, spriteSheet3, spriteSheet4, spriteSheet5]), 
   random(100, 500), random(100, 500), random(1, 5), random([-1, 1]), score);
    }
}

function mousePressed(){
  push();
  for(i = 0; i < count; i++){
    character[i].clicked();
  }
  pop();
}

function scoreControls(){
  push();
  score = 0;
  for(i = 0; i < count; i++){
    if(character[i].move == 0){
      score += 1;
    }
  }  
  pop();
  return score;
}

function draw(){
  background(0);

  if(gameState == 'wait'){
    fill(255);
    textSize(30);
    textFont("Trebuchet MS");
    text("Press the spacebar to start", 150, 300);
    if(keyCode === 32){
      startTime = millis();
      gameState = 'playing';
    }
  }else if(gameState == 'playing'){
    num_caught = 0;
    for(i = 0; i < count; i++){
      if(character[i].caught == true){
        num_caught ++;
      }
    }
    for(i = 0; i < count; i++){
      character[i].draw(num_caught);
    }
    score = scoreControls();
    time = timer();
    let totalTime = 30;
    fill(255);
    textSize(30);
    textFont("Trebuchet MS");
    text("TIME: " + (totalTime - time), 10, 30);
    text("SCORE: " + score, 10, 60);
    if (time >= totalTime || score == count){
      gameState = 'end';
  }
  }else if(gameState == 'end'){
    fill(255);
    textSize(30);
    textFont("Trebuchet MS");
    text("Game Over", 150, 200);
    text("Press the spacebar to restart", 150, 300);
    if (keyIsPressed){
      if(keyCode === 32){
        setup();
        startTime = millis();
        gameState = 'playing';
      }
    }
  }
}
class Character{
  constructor(spriteSheet, x, y, speed, move){
    this.spriteSheet = spriteSheet;
    this.sx = 0;
    this.x = x;
    this.y = y;
    this.move = 0;
    this.facing = 1;
    this.speed = speed;
    this.move = move;
    this.facing = move;
  }

  draw(num_caught){
    push();
    translate(this.x, this.y);
    scale(this.facing, 1);

    if(this.move == 0){
      image(this.spriteSheet, 0, 0, 80, 80, 800, 0, 80, 80);
    }else{
      image(this.spriteSheet, 0, 0, 80, 80, 80 * (this.sx + 1), 0, 80, 80);
    }

    if(frameCount % 5 == 0){
      this.sx = (this.sx + 1) % 8;
    }
    this.x += (this.speed + num_caught) * this.move;

    if(this.x < 30){
      this.move = 1;
      this.facing = 1;
    }else if(this.x > width - 30){
      this.move = -1;
      this.facing = -1;
    }
    pop();
  }

  go(direction){
    this.move = direction;
    this.facing = direction;
    this.sx = 3;
  }

  stop(){
    this.move = 0;
  }

  clicked(){
    if(mouseX > this.x - 40 && mouseX < this.x + 40 &&
      mouseY > this.y - 40 && mouseY < this.y + 40){
      this.stop();
      this.caught = true;
    }
  }
}
